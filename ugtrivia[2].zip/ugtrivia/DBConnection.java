/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.ugtrivia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import java.sql.Statement;
/**
 *
 * @author user
 */
public class DBConnection {
   public static void main(String[] args) {
 
String dbURL = "org.apache.derby.jdbc.EmbeddedDriver";
Connection conn = null;
 
try {
Class.forName(dbURL).newInstance();
conn = DriverManager.getConnection("jdbc:derby:"
+ "UGTrivia;create=true");
} catch (Exception except) {
except.printStackTrace();
}
 
if (conn != null) {
System.out.println("connected");
 
ResultSet rs = null;
Statement smt1 = null;
Statement smt2 = null;
Statement smt3 = null;
int a = 0;
 
try {
smt1 = conn.createStatement();
smt2 = conn.createStatement();
smt3 = conn.createStatement();
a = smt1.executeUpdate("CREATE TABLE PASQUO (COURSEID INT,COURSECODE VARCHAR(10))");
 
System.out.println("Table created");
 
a = smt2.executeUpdate("insert into PASQUO values (2,'ABCS 204')");
 
System.out.println("Values inserted");
 
rs = smt3.executeQuery("select * from PASTQUOs");
while (rs.next())
System.out.println("Values in the table are: "
+ rs.getString(1) + "," + rs.getString(2));
conn.close();
} catch (Exception e) {
e.printStackTrace();
}
}
}
}

